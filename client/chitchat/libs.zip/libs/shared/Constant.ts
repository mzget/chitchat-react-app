export const X_MASTER_KEY = "x-master-key";
export const X_API_KEY = "x-api-key";
export const X_DEVICE_INFO = "x-device-info";
export const X_ACCESS_TOKEN = "x-access-token";
export const X_GEOIP = "x-geoip";