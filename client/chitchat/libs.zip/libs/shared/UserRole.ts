export enum UserRole {
    personnel = 0,
    section_chief,
    department_chief,
    division_chief,
    admin
};