
export const textType = /text.*/;
export const imageType = /image.*/;
export const videoType = /video.*/;
export const file = /application.*/;